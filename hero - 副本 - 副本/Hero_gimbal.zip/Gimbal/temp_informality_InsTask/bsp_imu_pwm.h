#ifndef BSP_IMU_PWM_H
#define BSP_IMU_PWM_H
#include "stdint.h"

void imu_pwm_set(uint16_t pwm);

#endif
